Dhruv Sanchety, 705001374, dsanchety08@gmail.com
Siddharth Joshi, 105032378, sjoshi804@gmail.com

Sources:

https://scikit-learn.org/stable/modules/generated/sklearn.cluster.KMeans.html
https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html
https://scikit-learn.org/stable/modules/generated/sklearn.cluster.AgglomerativeClustering.html
https://docs.opencv.org/master/da/df5/tutorial_py_sift_intro.html
https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_feature2d/py_surf_intro/py_surf_intro.html
https://docs.opencv.org/master/d0/d13/classcv_1_1Feature2D.html
https://docs.opencv.org/3.4/db/d95/classcv_1_1ORB.html
https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_feature2d/py_matcher/py_matcher.html
https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html
